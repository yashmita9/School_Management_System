package com.erp.school.entity;

import com.erp.school.common.BaseEntity;
import com.erp.school.entityenum.Status;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Table;

/**
 * Subject master entity. Stores all school subjects.
 * 
 * Examples: Mathematics, English, Physics
 * 
 * @author Yashmita Rathore
 */
@Entity
@Table(name = "subjects")
public class SubjectEntity extends BaseEntity {

	@Column(name = "subject_code")
	private String subjectCode;

	@Enumerated(EnumType.STRING)
	@Column(name = "status")
	private Status status;

	@Column(name = "subject_name", nullable = false, length = 100)
	private String subjectName;

	@Column(name = "description", length = 255)
	private String description;

	public String getSubjectCode() {
		return subjectCode;
	}

	public void setSubjectCode(String subjectCode) {
		this.subjectCode = subjectCode;
	}

	public String getSubjectName() {
		return subjectName;
	}

	public void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}
}